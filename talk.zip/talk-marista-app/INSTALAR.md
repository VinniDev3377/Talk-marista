# Talk Marista — app para iPhone (PWA)

Esta pasta é o aplicativo pronto. Envie-a para uma hospedagem HTTPS pública e instale no iPhone.

## 1) Publicar (grátis)
**Netlify Drop** (https://app.netlify.com/drop): arraste a pasta `talk-marista-app` e use o link gerado.
Para atualizar um site existente: no painel do site, aba **Deploys**, arraste a pasta nova.
O site precisa estar **público** (sem proteção por senha ou login do Netlify). Teste numa aba anônima.

Alternativas: Cloudflare Pages, Vercel, GitHub Pages (`index.html` na raiz).

## 2) Instalar no iPhone
Abra o link no **Safari** → Compartilhar → **Adicionar à Tela de Início**.

## Entrar (demonstração; nada vem preenchido)
- Morador: `morador` / `marista123` (escolha o apartamento, ex.: 1203)
- Portaria: `portaria` / `portaria123`
- Administrador: `admin` / `admin123`

## O que cada perfil faz
- **Portaria**: tudo o que é operacional, em abas (encomendas com foto, visitantes, prestadores, moradores, reservas, mudanças, solicitações).
- **Morador**: só consulta (encomendas, visitantes e prestadores do seu apto) e vê o calendário de reservas de cada espaço, sem saber qual apartamento reservou.
- **Admin**: vê o painel da portaria em modo consulta.

## Importante
- Os dados ficam **só no aparelho** (sem banco de dados): o que a portaria cadastra num celular não aparece no celular do morador.
- A câmera exige **HTTPS**.
- Depois de atualizar o site, no iPhone feche e reabra o app (se não mudar, remova o ícone e adicione de novo).
