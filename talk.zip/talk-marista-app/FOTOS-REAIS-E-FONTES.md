# Talk Marista — fotos reais aplicadas

Esta atualização altera somente as referências visuais das imagens. Nenhuma tela, regra de negócio, cadastro, reserva, autenticação, navegação, armazenamento ou permissão foi modificada.

## Imagens utilizadas

- **Imagem principal / acesso do condomínio:** foto de entrada identificada como Talk Marista em anúncio imobiliário na Chaves na Mão.
  - https://www.chavesnamao.com.br/imn/0850x0450/N/60/imoveis/1009917/35406938/go-goiania-setor-marista-avenida-mutirao-apartamento-a-venda-3-quartos-698c9bb5-1.jpg
- **Espaço Grill:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-6.webp
- **Salão de Festas:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-15.webp
- **Espaço Gourmet:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-14.webp
- **Brinquedoteca:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-11.webp
- **Academia:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-10.webp
- **Salão de Jogos:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-13.webp
- **Piscina / área molhada:** https://seuimovelgoiania.com.br/wp-content/uploads/2024/04/talk-marista-8.webp

As fotos das áreas comuns são apresentadas pela imobiliária Seu Imóvel Goiânia como imagens do Talk Marista pronto. A imagem principal vem de anúncio imobiliário da Chaves na Mão.

## Observação técnica

As imagens são carregadas de endereços HTTPS externos para manter intactos os arquivos e o comportamento do aplicativo. Portanto, é necessária conexão com a internet para exibi-las. Se os sites de origem alterarem os endereços, bloquearem o carregamento externo ou retirarem as imagens, será necessário atualizar as URLs ou substituir os arquivos por cópias autorizadas. Os SVGs originais continuam no pacote como recursos de reserva, mas não foram usados nas áreas que receberam fotografia.

## Fontes consultadas

- Apto: https://apto.vc/br/go/goiania/setor-marista/talk-marista
- Seu Imóvel Goiânia: https://seuimovelgoiania.com.br/talk-marista/
- Chaves na Mão: https://www.chavesnamao.com.br/imovel/apartamento-a-venda-3-quartos-com-garagem-go-goiania-setor-marista-137m2-RS1490000/id-35406938/
